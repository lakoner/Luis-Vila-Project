<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Actualidad;
use Faker\Generator as Faker;

$factory->define(actualidad::class, function (Faker $faker) {
    return [
        //
    ];
});
