<?php

namespace App\Http\Controllers;

use App\Categotia;
use Illuminate\Http\Request;

class CategotiaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Categotia  $categotia
     * @return \Illuminate\Http\Response
     */
    public function show(Categotia $categotia)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Categotia  $categotia
     * @return \Illuminate\Http\Response
     */
    public function edit(Categotia $categotia)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Categotia  $categotia
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Categotia $categotia)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Categotia  $categotia
     * @return \Illuminate\Http\Response
     */
    public function destroy(Categotia $categotia)
    {
        //
    }
}
