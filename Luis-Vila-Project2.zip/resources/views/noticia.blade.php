@extends('templates.header_footer_front')


@section('content')
<body onload="menuNoticia()">




<div class="content-noticia">

    @foreach($actualidades as $actualidad)
      <div class="noticia-top">
          <div class="content-image-noticia">
                <img class="img-noticia" src="{{asset('storage').'/'.$actualidad->image}}" alt="">

            </div><p class="date-noticia"><small>{{$actualidad->date}}</small></p>

            <div class="slide-noticia">
                <div class="scroll">
                    @foreach($noticiaSlide as $actualidad)
                    <a href="{{url('/noticia/'.$actualidad->id)}}"><div class="img-slide"><img class="img-noticia" src="{{asset('storage').'/'.$actualidad->image}}" alt=""></div>
            <div class="slide-title">{{$actualidad->title}}</div></a>
            @endforeach
            </div>
        </div>

        </div>



<h1>{{$actualidad->title}}</h1>
<h4><i>{{$actualidad->subtitle}}</i></h4>
<div class="noticia-text"><p>{{$actualidad->text}}</p></div>

<br>
<div class="botones">
			<div class="share-buttons-row">
                <!--Facebook's Button -->
                <div class="share-fb"></div>
                <!--Twitter's Button -->
                <div class="share-twitter"></div>
                <!--Linkedin's Button -->
        </div>
</div
<br>




@endforeach


<script>
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');
</script>
</div>
</body>
@endsection
