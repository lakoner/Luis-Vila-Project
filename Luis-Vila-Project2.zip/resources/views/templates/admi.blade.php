

    <div class="content-menu">
            <div class="admin-menu ">
                <nav>
                    <ul class="navbar-nav">
                        <li class="selected"><a href="{{url('/obra')}}">Obra</a></li>

                        <li><a href="{{url('/obra/create')}}">Pujar obra</a></li>

                        <li><a href="{{url('/actualidad')}}">Noticies</a></li>

                        <li> <a href="{{url('/actualidad/create')}}">Pujar Noticies</a></li>

                        <li><a href="{{url('/register')}}">Crear nou usuari</a></li>
                    </ul>



                </nav>
            </div>









