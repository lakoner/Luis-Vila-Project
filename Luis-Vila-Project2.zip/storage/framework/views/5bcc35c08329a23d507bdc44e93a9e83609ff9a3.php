<?php $__env->startSection('content'); ?>
<div class="content-admin">


    <div class="actualidad-content">
            <div class="content-header">
                <h1><i class="fas fa-newspaper"></i>&nbsp;<b>Usuarios</b>
                    <div class="btn-group btn-group-toggle float-right" data-toggle="buttons">
                        <a href="<?php echo e(url('/actualitat')); ?>" target="_blank">
                        <label class="btn btn-secondary header-left-button">
                               Vista previa
                        </label> </a>
                          <a href="<?php echo e(url('/actualidad/create')); ?>">
                          <label class="btn btn-secondary header-right-button">
                                 Nova Noticia
                        </label>
                    </a>
                    </div>
                </h1>
            </div>


            <br><br><br>     <br><br><br>     <br><br><br>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h1><?php echo e($user->mail); ?></h1>
            <h1><?php echo e($user->mail); ?></h1>
            <h1><?php echo e($user->mail); ?></h1>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/usuarios.blade.php ENDPATH**/ ?>