<?php $__env->startSection('content'); ?>

<main class="content-framwork-1">

<?php $__currentLoopData = $actualidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actualidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h1><?php echo e($actualidad->title); ?></h1>
<h1><?php echo e($actualidad->subtitle); ?></h1>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.header_footer_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/noticies.blade.php ENDPATH**/ ?>