<footer>
    <div class="footer">
        <div class="content">
            <ul>
                <li>LLUÍS VILÀ</li><div class="lv"></div>
                <a href="http://www.fundaciolluiscoromina.org/"> <li> &copy  Fundació Lluís Coromina</a></li><div class="lv"></div>
                <a href="mailto:fundacio@fundaciolluiscoromina.org"> <li> fundacio@fundaciolluiscoromina.org</a></li><div class="lv"></div>
                <a href="tel:+3400972583477"> <li>Telf. 972 58 34 77</a></li><a href="#"><div class="insta"></a></div><a href="http://www.factoriaf5.org/"><div class="f5"></div></a>
            </ul>
        </div>

    </div>

</footer>
</body>
</html>
<?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/templates/footer_front.blade.php ENDPATH**/ ?>