<?php $__env->startSection('content'); ?>
<body onload="menuPintura()">


    <div class="content-framwork-1">
        <div class="inter-menu">
            <nav>
                <a id="eat_art" href="<?php echo e(url('/eat_art')); ?>">Eat Art</a>
                <a id="diseño" href="<?php echo e(url('/diseño')); ?>">Diseño</a>
                <a id="escultura" href="<?php echo e(url('/escultura')); ?>">Escultura</a>
                <a id="pintura" href="<?php echo e(url('/pintura')); ?>">Pintura</a>
                <a id="volcan" href="<?php echo e(url('/volcan')); ?>">volcan</a>
            </nav>

            <div class="filter-series float-right">
                <form action="<?php echo e(Route('serie.filterSerie')); ?>">
                    <label>
                    <select class="form-control" name="serie_id">
                        <option hidden selected> Filtra por Series</option>
                            <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($serie->id); ?>"><?php echo e($serie->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                        </label>
                        <label><input class="form-control filter-button-color" type="submit" value="Filtra"></label>
                </form>
                       <a href="<?php echo e(url('/pintura/')); ?>"><input class="form-control filter-todas-button" type="submit" value="Todas"></a>

            </div>
        </div>
        <br><br>




<br><br>


        <div class="content-obras">
            <?php $__currentLoopData = $obras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="box">
            <a href="#"> <img class="obra-img" src="<?php echo e(asset('storage').'/'.$obra->image); ?>" data-toggle="modal" data-target="#image<?php echo e($obra->id); ?>" data-whatever="@mdo" alt="" name="image"></a>
                <div class="content-info">
                    <div> <h4><b><?php echo e($obra->name); ?></b></h4></div>
                    <div> <h4><b><?php echo e($obra->serie->name); ?></b></h4></div>


                </div>
            </div>

            <div class="modal fade" id="image<?php echo e($obra->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header modal-close">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <img class="modal-img" src="<?php echo e(asset('storage').'/'.$obra->image); ?>" alt="" name="image">

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tanca</button>
                            </div>
                        </div>
                    </div>
                </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</div>

</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.header_footer_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views//pintura.blade.php ENDPATH**/ ?>