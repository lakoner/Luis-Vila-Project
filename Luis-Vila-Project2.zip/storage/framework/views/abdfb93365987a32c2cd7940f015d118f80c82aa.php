


<?php $__env->startSection('content'); ?>
<main class="content-framwork-1">
<div class="content-obra-menu">
<div class="eat-art"><a href="<?php echo e(url('/eat_art/')); ?> "><h3>EAT ART</h3></a></div>
<div class="escultura"><a href="#"><h3>ESCULTURA</h3></a></div>
<div class="volca"><a href="#"><h3>VOLCÀ</h3></a></div>
<div class="pintura"><a href="#"><h3>PINTURA</h3></a></div>
<div class="disseny"><a href="#"><h3>DISSENY</h3></a></div>




</div>
</main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('templates.header_footer_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/obra.blade.php ENDPATH**/ ?>