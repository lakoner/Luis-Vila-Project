<?php $__env->startSection('content'); ?>
<body onload="menuNoticia()">




<div class="content-noticia">

    <?php $__currentLoopData = $actualidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actualidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="noticia-top">
          <div class="content-image-noticia">
                <img class="img-noticia" src="<?php echo e(asset('storage').'/'.$actualidad->image); ?>" alt="">

            </div><p class="date-noticia"><small><?php echo e($actualidad->date); ?></small></p>

            <div class="slide-noticia">
                <div class="scroll">
                    <?php $__currentLoopData = $noticiaSlide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actualidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('/noticia/'.$actualidad->id)); ?>"><div class="img-slide"><img class="img-noticia" src="<?php echo e(asset('storage').'/'.$actualidad->image); ?>" alt=""></div>
            <div class="slide-title"><?php echo e($actualidad->title); ?></div></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        </div>



<h1><?php echo e($actualidad->title); ?></h1>
<h4><i><?php echo e($actualidad->subtitle); ?></i></h4>
<div class="noticia-text"><p><?php echo e($actualidad->text); ?></p></div>

<br>
<div class="botones">
			<div class="share-buttons-row">
                <!--Facebook's Button -->
                <div class="share-fb"></div>
                <!--Twitter's Button -->
                <div class="share-twitter"></div>
                <!--Linkedin's Button -->
        </div>
</div
<br>




<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<script>
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');
</script>
</div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.header_footer_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/noticia.blade.php ENDPATH**/ ?>