<?php $__env->startSection('content'); ?>

<main class="content-framwork-1">
        <?php $__currentLoopData = $actualidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actualidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('/noticia/'.$actualidad->id)); ?>">
                <div class="content-news card">
                    <div class="content-image-news card">
                        <img  src="<?php echo e(asset('storage').'/'.$actualidad->image); ?>" alt="">
                    </div>
                    <div class="content-data-news">
                        <h1><?php echo e($actualidad->title); ?></h1>
                        <h4><?php echo e($actualidad->subtitle); ?></h4>
                    <div class="text-news-front"><p><?php echo e($actualidad->text); ?></p></div>
                        <p class="date"><small><?php echo e($actualidad->date); ?></small></p>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</main>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('templates.header_footer_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/noticias.blade.php ENDPATH**/ ?>