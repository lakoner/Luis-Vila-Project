<?php $__env->startSection('content'); ?>
<main class="content-admin">
    <br><br>

    <div class="row">

        <div class="col-md-3"></div>
        <div class="card col-md-6"><br>
        <form class="form-group" method="POST" action="<?php echo e(Route('actualidad.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                     <div class="form-group">
                    <label for="">Títol Notícia</label>
                    <input class="form-control" type="text" name="title">
                </div>

                <div class="form-group">
                    <label for="">Subtítol Noticia</label>
                    <input class="form-control" type="text" name="subtitle">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Text Notícia</label>
                    <textarea class="form-control" name="text" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="">Imatge Noticia</label><br>
                    <input type="file" name="image">
                </div>


                <button class="btn btn-primary">Afegir Noticia</button>

            </form>
        </div>
        <div class="col-md-3"></div>
    </div>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/noticia/create.blade.php ENDPATH**/ ?>