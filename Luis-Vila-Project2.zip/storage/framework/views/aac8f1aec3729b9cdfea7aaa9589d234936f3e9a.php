<?php $__env->startSection('content'); ?>

<div class="content-admin">


<div class="actualidad-content">
            <div class="content-header">

 <form action="<?php echo e(Route('obra.filter')); ?>">
               <h1><i class="fas fa-palette"></i>&nbsp;<b>Obras</b>

               <div class="btn-group btn-group-toggle float-right" data-toggle="buttons">

                        <a href="<?php echo e(url('/obras')); ?>" target="_blank">
                            <label class="btn btn-secondary header-left-button">
                                <b>Vista previa</b>
                            </label>
                        </a>

                        <a href="<?php echo e(url('/obra/create')); ?>">
                        <label class="btn btn-secondary btn-header-between-buttons">
                            <b>Nueva Obra</b>
                        </label>
                     </a>

                     <label class="btn btn-secondary btn-header-between-buttons">

                                <select class=" form-control" name="categoria_id">
                                <option class="selected" hidden>Filtra por Categoria</option>

                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>

                        <button class="btn btn-secondary btn-header-between-buttons filter-btn">
                           Filtrar
                        </button>

                         <a href="<?php echo e(url('/obra')); ?>">
                         <label class="btn btn-secondary header-right-button">
                               <b>Todas</b>
                        </label>

                        </a></h1>


             </div></form>

            <br><br><br>


<div class="content-table">
     <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>Imagen</th>
                        <th>Nombre</th>
                        <th>Técnica</th>
                        <th class="th-small">Año</th>
                        <th>Categoria</th>
                        <th>Serie</th>
                        <th>Creación</th>
                        <th>Modificación</th>
                        <th class="th-small">Edita</th>
                        <th class="th-small">Elimina</th>
                    </tr>
                </thead>

            <?php $__currentLoopData = $obras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td class="img">
                        <a href="#">
                            <i class="far fa-eye fa-2x" data-toggle="modal" data-target="#image<?php echo e($obra->id); ?>" data-whatever="@mdo"></i>
                        </a>
                            <img class="img-obras-index" src="<?php echo e(asset('storage').'/'.$obra->image); ?>" alt="" name="image">
                    </td>
                    <td><?php echo e($obra->name); ?></div></td>
                    <td><?php echo e($obra->technique); ?></td>
                    <td><?php echo e($obra->year); ?></td>
                    <td><?php echo e($obra->categoria->name); ?></td>
                    <td><?php echo e($obra->serie->name); ?></td>

                    <td class="timestamp"><div ><?php echo e($obra->created_at); ?></div></td>
                    <td><?php echo e($obra->updated_at); ?></td>
                    <td class="cta"><a href="<?php echo e(Route('obra.edit', $obra->id)); ?>">
                        <button class="button-edit btn btn-secondary"><i class="far fa-edit"></i></button> </a>
                    </td>
                    <td class="cta">
                        <form action="<?php echo e(Route('obra.destroy', $obra->id)); ?>" method="post"> <?php echo method_field('delete'); ?><?php echo csrf_field(); ?>
                            <button class="btn btn-secondary button-delete" onclick="return confirm ('¿Estas seguro que quieres eliminar<?php echo e($obra->name); ?> de manera permanente?')">
                            <i class="far fa-trash-alt"></i>
                        </form>
                    </td>
                </tr>

                <div class="modal fade" id="image<?php echo e($obra->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header modal-close-obras">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <img class="modal-img" src="<?php echo e(asset('storage').'/'.$obra->image); ?>" alt="" name="image">

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tanca</button>
                            </div>
                        </div>
                    </div>
                </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
        </div>


    </div>
</div>
</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/obra/index.blade.php ENDPATH**/ ?>