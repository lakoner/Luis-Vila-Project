


<?php $__env->startSection('content'); ?>
<main class="content-framwork-1">
<div class="content-obra-menu">
<div class="eat-art"><a href="<?php echo e(url('/eat_art/')); ?> "><h3>EAT ART</h3></a></div>
<div class="escultura"><a href="<?php echo e(url('/escultura/')); ?>"><h3>ESCULTURA</h3></a></div>
<div class="volca"><a href="<?php echo e(url('/volcan/')); ?>"><h3>VOLCÁN</h3></a></div>
<div class="pintura"><a href="<?php echo e(url('/pintura/')); ?>"><h3>PINTURA</h3></a></div>
<div class="disseny"><a  href="<?php echo e(url('/diseño/')); ?>"><h3>DISEÑO</h3></a></div>




</div>
</main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('templates.header_footer_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/obras.blade.php ENDPATH**/ ?>