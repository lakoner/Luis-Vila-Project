<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

        <title><?php echo e(config('app.name', 'Lluís Vilà')); ?></title>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>



        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com" />
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"/>
        <link href="https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300;1,400;1,500&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" integrity="sha384-Bfad6CLCknfcloXFOyFnlgtENryhrpZCe29RTifKEixXQZ38WheV+i/6YWSzkz3V"crossorigin="anonymous"/>

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/fonts.css')); ?>" rel="stylesheet">


        <!-- Scripts ajax y bootstrap -->

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>



    </head>
    <body>
    <header>
        <div class="header">
            <div class="menu"><h1 class="logo"><a href="<?php echo e(url('/')); ?>">LLUÍS VILÀ</a></h1>
                <nav>
                    <a href="<?php echo e(url('/obras/')); ?>">OBRA</a>
                    <a href="<?php echo e(url('/biografia/')); ?>">BIOGRAFÍA</a>
                    <a href="<?php echo e(url('/actualitat/')); ?>">ACTCUALITAT</a>
                    <a href="<?php echo e(url('/prensa/')); ?>">PRENSA</a>
                    <a href="<?php echo e(url('/contactar/')); ?>">CONTACTAR</a>
                </nav>
                <div class="lang">
                    <a href="">CAT</a>
                    <a href="">ES</a>
                </div>

            </div>

        </div>

    </header>

    <body>





<div class="content-framwork-1">
    <div class="inter-menu">
        <nav>
            <a tabindex="1" class="nav-obras" href="<?php echo e(url('/eat_art')); ?>">Eat Art</a>
            <a tabindex="2" class="nav-obras" href="<?php echo e(url('/diseño')); ?>">Disseny</a>
            <a tabindex="3" class="nav-obras" href="<?php echo e(url('/escultura')); ?>">Escultura</a>
            <a tabindex="4" class="nav-obras" href="<?php echo e(url('/pintura')); ?>">Pintura</a>
            <a tabindex="5" class="nav-obras" href="<?php echo e(url('/volca')); ?>">Volcà</a>

        </nav>
    </div>
</div>

    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>




<?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/templates/inter-menu-obras.blade.php ENDPATH**/ ?>