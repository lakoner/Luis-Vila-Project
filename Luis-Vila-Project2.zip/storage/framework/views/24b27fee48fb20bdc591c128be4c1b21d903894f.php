

    <div class="content-menu">
            <div class="admin-menu ">
                <nav>
                    <ul class="navbar-nav">
                        <li class="selected"><a href="<?php echo e(url('/obra')); ?>">Obra</a></li>

                        <li><a href="<?php echo e(url('/obra/create')); ?>">Pujar obra</a></li>

                        <li><a href="<?php echo e(url('/actualidad')); ?>">Noticies</a></li>

                        <li> <a href="<?php echo e(url('/actualidad/create')); ?>">Pujar Noticies</a></li>

                        <li><a href="<?php echo e(url('/register')); ?>">Crear nou usuari</a></li>
                    </ul>



                </nav>
            </div>









<?php /**PATH C:\Users\Axel\Documents\AXEL\CODER\FACTORIAF5\GIT\LLUIS VILA\Luis-Vila-Project\resources\views/templates/admin-menu.blade.php ENDPATH**/ ?>